export default function NotFound() {
    return (<>NotFound</>)
}